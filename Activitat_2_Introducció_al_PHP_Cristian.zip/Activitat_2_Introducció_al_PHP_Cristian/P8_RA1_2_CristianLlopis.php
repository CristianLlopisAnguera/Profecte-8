<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Declara variables i mostra una frase amb la informació personal.

$nom = "Cristian";
$edat = 19;
$ciutat = "Mora la nova";

echo "Em dic $nom, tinc $edat anys i visc a $ciutat.";
?>