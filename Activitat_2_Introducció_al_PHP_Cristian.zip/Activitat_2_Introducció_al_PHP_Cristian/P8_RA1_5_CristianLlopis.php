<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Script amb comentaris de línia i de bloc.

// Aquest comentari és de línia
$nom = "Cristian";

/*
Aquest bloc explica que imprimim
el nom a la pantalla
*/
echo "El meu nom és $nom";
?>
