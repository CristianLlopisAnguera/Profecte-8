<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Defineix una constant i la mostra.

define("CENTRE", "Institut XYZ");

echo "Estudio a " . CENTRE;
?>
