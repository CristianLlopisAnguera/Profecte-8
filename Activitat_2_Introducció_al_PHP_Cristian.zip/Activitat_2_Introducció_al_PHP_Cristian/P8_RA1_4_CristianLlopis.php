<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Mostra la data i hora actuals.

$data = date("d/m/Y");
$hora = date("H:i");

echo "Avui és $data i són les $hora.";
?>
