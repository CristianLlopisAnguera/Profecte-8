<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Mostra variables de diferents tipus amb var_dump().

$cadena = "Hola";
$enter = 10;
$decimal = 3.14;
$boolea = true;

var_dump($cadena);
var_dump($enter);
var_dump($decimal);
var_dump($boolea);
?>
