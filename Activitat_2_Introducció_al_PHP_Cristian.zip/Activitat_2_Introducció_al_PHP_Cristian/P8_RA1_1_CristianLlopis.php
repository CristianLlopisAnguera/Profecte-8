<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Mostra per pantalla el missatge Hola món amb PHP.

echo "Hola món";
?>
