<!--
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Mostra un missatge personalitzat dins un paràgraf HTML.
-->

<!DOCTYPE html>
<html>
<head>
    <title>Missatge personalitzat</title>
</head>
<body>
    <p>
        <?php
        echo "Benvingut a la meva pàgina personal!";
        ?>
    </p>
</body>
</html>