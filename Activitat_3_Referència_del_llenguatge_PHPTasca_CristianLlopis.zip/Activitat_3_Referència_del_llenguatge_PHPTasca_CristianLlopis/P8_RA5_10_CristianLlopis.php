<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Crea un array multidimensional amb dades de 3 usuaris. Fes una funció que indiqui si cada usuari és major d’edat i mostra-ho en una taula HTML.
<?php
$usuaris = [
    ["nom" => "Anna", "correu" => "anna@example.com", "edat" => 17],
    ["nom" => "Marc", "correu" => "marc@example.com", "edat" => 20],
    ["nom" => "Joan", "correu" => "joan@example.com", "edat" => 18]
];

function esMajor($edat) {
    return $edat >= 18 ? "Sí" : "No";
}

echo "<table border='1'><tr><th>Nom</th><th>Correu</th><th>Edat</th><th>Major d'edat</th></tr>";
foreach ($usuaris as $usuari) {
    echo "<tr><td>{$usuari['nom']}</td><td>{$usuari['correu']}</td><td>{$usuari['edat']}</td><td>" . esMajor($usuari['edat']) . "</td></tr>";
}
echo "</table>";
?>
