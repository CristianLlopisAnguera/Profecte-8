<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <title>Resultat IVA</title>
</head>
<body>
  <h1>Resultat del càlcul d'IVA</h1>

  <?php
    // Funció que calcula el preu amb l'IVA aplicat
    function calcularPreuAmbIVA($preu, $percentatgeIVA): float|int {
      $preuAmbIVA = $preu + ($preu * $percentatgeIVA / 100);
      return $preuAmbIVA;
    }

    // Recollim els valors enviats pel formulari
    $preu = $_POST['preu'];
    $iva = $_POST['iva'];

    // Calculem el resultat
    $resultat = calcularPreuAmbIVA(preu: $preu, percentatgeIVA: $iva);

    // Mostrem el resultat
    echo "<p>Preu original: $preu €</p>";
    echo "<p>IVA aplicat: $iva %</p>";
    echo "<p><strong>Preu total amb IVA: " . number_format(num: $resultat, decimals: 2) . " €</strong></p>";
  ?>

  <a href="index.html">Tornar a calcular</a>
</body>
</html>