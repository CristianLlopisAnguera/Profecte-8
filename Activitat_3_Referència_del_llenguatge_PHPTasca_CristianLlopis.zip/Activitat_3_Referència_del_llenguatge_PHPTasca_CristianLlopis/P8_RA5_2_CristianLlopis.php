<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Introdueix un número i mostra si és parell o senar.
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num = intval($_POST["numero"]);
    echo $num % 2 == 0 ? "El número és parell." : "El número és senar.";
}
?>
<form method="post">
    Introdueix un número: <input type="number" name="numero">
    <input type="submit" value="Enviar">
</form>
