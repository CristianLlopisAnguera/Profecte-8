<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Introdueix un número i mostra si és parell o senar.
?>

<?php
// Comprovem si el formulari s'ha enviat mitjançant el mètode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Convertim el valor rebut del camp "numero" a un enter
    $num = intval($_POST["numero"]);

    // Comprovem si el número és parell (divisible per 2) o senar, i mostrem el missatge corresponent
    echo $num % 2 == 0 ? "El número és parell." : "El número és senar.";
}
?>

<form method="post">
    Introdueix un número: <input type="number" name="numero">
    <input type="submit" value="Enviar">
</form>