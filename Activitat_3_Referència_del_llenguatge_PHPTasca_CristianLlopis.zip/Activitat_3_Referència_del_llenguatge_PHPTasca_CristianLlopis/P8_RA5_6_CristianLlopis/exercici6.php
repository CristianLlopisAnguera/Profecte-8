<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <title>Alumnes majors d'edat</title>
</head>
<body>
  <h1>Alumnes de 18 anys o més:</h1>
  <ul>
    <?php
      // Array associatiu amb noms com a claus i edats com a valors
      $alumnes = [
        "Laia" => 17,
        "Oriol" => 18,
        "Carla" => 20,
        "Nil" => 16,
        "Júlia" => 19
      ];

      // Recorrem l'array i mostrem només els alumnes amb 18 anys o més
      foreach ($alumnes as $nom => $edat) {
        if ($edat >= 18) {
          echo "<li>$nom - $edat anys</li>"; // Mostra nom i edat
        }
      }
    ?>
  </ul>

  <!-- Botó per tornar a la pàgina principal -->
  <a href="index.html">Tornar enrere</a>
</body>
</html>