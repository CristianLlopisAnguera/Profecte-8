<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Crea una funció que rebi un preu i un percentatge d’IVA i retorni el preu amb l’IVA aplicat.
?>
<?php
function calcularIVA($preu, $iva) {
    return $preu + ($preu * $iva / 100);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $preu = floatval($_POST["preu"]);
    $iva = floatval($_POST["iva"]);
    echo "Preu amb IVA: " . calcularIVA($preu, $iva);
}
?>
<form method="post">
    Preu: <input type="number" step="0.01" name="preu">
    IVA (%): <input type="number" step="0.1" name="iva">
    <input type="submit" value="Calcular">
</form>
