<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Demana l’edat d’una persona i mostra si és major d’edat o no.
?>

<?php
// Comprovem si el formulari s'ha enviat mitjançant el mètode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Convertim el valor rebut de l'input "edat" a un enter
    $edat = intval($_POST["edat"]);

    // Comprovem si l'edat és 18 o més i mostrem un missatge en conseqüència
    echo $edat >= 18 ? "Ets major d'edat." : "No ets major d'edat.";
}
?>

<form method="post">
    Introdueix la teva edat: <input type="number" name="edat">
    <input type="submit" value="Enviar">
</form>

