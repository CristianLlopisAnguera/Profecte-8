<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Demana l’edat d’una persona i mostra si és major d’edat o no.
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $edat = intval($_POST["edat"]);
    echo $edat >= 18 ? "Ets major d'edat." : "No ets major d'edat.";
}
?>
<form method="post">
    Introdueix la teva edat: <input type="number" name="edat">
    <input type="submit" value="Enviar">
</form>
