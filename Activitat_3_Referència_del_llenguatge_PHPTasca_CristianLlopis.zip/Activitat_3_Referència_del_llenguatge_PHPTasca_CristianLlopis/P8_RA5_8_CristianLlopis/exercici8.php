<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <title>Resultat Factorial</title>
</head>
<body>
  <h1>Resultat del Factorial</h1>

  <?php
    // Funció per calcular el factorial d’un nombre
    function factorial($n): int {
      $resultat = 1;

      // Multipliquem tots els enters positius fins a n
      for ($i = 1; $i <= $n; $i++) {
        $resultat *= $i;
      }

      return $resultat;
    }

    // Recollim el número del formulari
    $num = $_POST['numero'];

    // Comprovem que és un enter positiu
    if ($num >= 0) {
      $fact = factorial(n: $num);
      echo "<p>El factorial de $num és <strong>$fact</strong>.</p>";
    } else {
      echo "<p>Si us plau, introdueix un número enter positiu.</p>";
    }
  ?>

  <a href="index.html">Torna a calcular</a>
</body>
</html>