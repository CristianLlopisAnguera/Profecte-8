<?php 
# Administració de sistemes informàtics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció (programa): Demana un número de l’1 al 10 i mostra la seva taula de multiplicar amb un bucle.

# Comprovem si el formulari s'ha enviat mitjançant el mètode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    # Convertim el valor rebut del camp 'numero' a enter
    $num = intval($_POST["numero"]);

    # Generem la taula de multiplicar del número introduït
    for ($i = 1; $i <= 10; $i++) {
        # Multipliquem el número per l'índex actual del bucle i mostrem el resultat
        echo "$num x $i = " . ($num * $i) . "<br>";
    }
}
?>

<form method="post">
    Número (1-10): <input type="number" name="numero" min="1" max="10">
    <input type="submit" value="Mostrar">
</form>

