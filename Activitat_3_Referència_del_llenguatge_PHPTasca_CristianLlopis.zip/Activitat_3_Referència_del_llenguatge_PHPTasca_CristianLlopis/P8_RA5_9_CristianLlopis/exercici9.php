<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <title>Resultat Nota Mitjana</title>
</head>
<body>
  <h1>Resultat de l'Alumne</h1>

  <?php
    // Array amb les notes de l’alumne
    $notes = [6.5, 4.0, 7.2, 5.0, 8.0];

    // Calcular la mitjana: suma de les notes dividida entre el nombre de notes
    $mitjana = array_sum(array: $notes) / count(value: $notes);

    // Mostrem la mitjana amb dos decimals
    echo "<p>La nota mitjana és: <strong>" . number_format(num: $mitjana, decimals: 2) . "</strong></p>";

    // Comprovem si està aprovat o no
    if ($mitjana >= 5) {
      echo "<p>L'alumne està <strong>aprovat</strong>.</p>";
    } else {
      echo "<p>L'alumne està <strong>suspès</strong>.</p>";
    }
  ?>

  <a href="index.html">Tornar enrere</a>
</body>
</html>