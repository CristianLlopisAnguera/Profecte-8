<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <title>Usuaris</title>
  <style>
    table {
      border-collapse: collapse;
      width: 60%;
    }
    th, td {
      border: 1px solid #000;
      padding: 8px;
      text-align: left;
    }
  </style>
</head>
<body>
  <h1>Llista d'usuaris</h1>

  <?php
    // Array multidimensional amb dades de 3 usuaris
    $usuaris = [
      ["nom" => "Laura", "correu" => "laura@gmail.com", "edat" => 22],
      ["nom" => "Pau", "correu" => "pau@xtec.cat", "edat" => 17],
      ["nom" => "Marta", "correu" => "marta@hotmail.com", "edat" => 18]
    ];

    // Funció per comprovar si un usuari és major d'edat
    function esMajorEdat($edat): bool {
      return $edat >= 18;
    }
  ?>

  <table>
    <tr>
      <th>Nom</th>
      <th>Correu</th>
      <th>Edat</th>
      <th>Major d'edat</th>
    </tr>

    <?php
      // Recorrem cada usuari i mostrem les seves dades a la taula
      foreach ($usuaris as $usuari) {
        echo "<tr>";
        echo "<td>{$usuari['nom']}</td>";
        echo "<td>{$usuari['correu']}</td>";
        echo "<td>{$usuari['edat']}</td>";
        
        // Indiquem si és major d'edat o no
        if (esMajorEdat($usuari['edat'])) {
          echo "<td>Sí</td>";
        } else {
          echo "<td>No</td>";
        }

        echo "</tr>";
      }
    ?>
  </table>

  <br>
  <a href="index.html">Tornar enrere</a>
</body>
</html>