<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <title>Noms</title>
</head>
<body>
  <h1>Llista de noms:</h1>
  <ul>
    <?php
      // Definim un array amb 5 noms
      $noms = ["Anna", "Jordi", "Clàudia", "Pere", "Marc"];

      // Recorrem l'array i mostrem cada nom dins d'una llista
      foreach ($noms as $nom) {
          echo "<li>$nom</li>"; // Mostra cada nom com un element de llista
      }
    ?>
  </ul>

  <!-- Enllaç per tornar a la pàgina inicial -->
  <a href="index.html">Tornar enrere</a>
</body>
</html>