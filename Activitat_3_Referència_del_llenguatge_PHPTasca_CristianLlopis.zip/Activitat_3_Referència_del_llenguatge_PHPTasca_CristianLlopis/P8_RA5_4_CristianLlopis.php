<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Mostra els números del 10 a l’1 utilitzant un bucle while.
<?php
$i = 10;
while ($i >= 1) {
    echo "$i<br>";
    $i--;
}
?>
