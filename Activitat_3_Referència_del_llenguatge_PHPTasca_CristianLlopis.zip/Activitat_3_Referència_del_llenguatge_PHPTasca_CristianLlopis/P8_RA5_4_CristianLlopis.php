<?php 
# Administració de sistemes informàtics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció (programa): Mostra els números del 10 a l’1 utilitzant un bucle while.
?>

<?php
# Inicialitzem la variable amb el valor 10
$i = 10;

# Bucle while que s'executa mentre $i sigui més gran o igual que 1
while ($i >= 1) {
    # Mostrem el valor actual de $i seguit d'un salt de línia
    echo "$i<br>";

    # Decrementem $i en 1 en cada iteració
    $i--;
}
?>

