<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Crea un array amb 5 noms i mostra cada nom amb un bucle foreach.
<?php
$noms = ["Anna", "Marc", "Joan", "Laia", "Pau"];
foreach ($noms as $nom) {
    echo "$nom<br>";
}
?>
