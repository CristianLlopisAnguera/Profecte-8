<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat del comptador</title>
</head>
<body>
    <h1>Resultat del comptador</h1>

    <?php
    // Comprovem si s'ha rebut un número vàlid
    if (isset($_GET['inici']) && is_numeric($_GET['inici'])) {
        $numero = (int) $_GET['inici'];

        if ($numero >= 1 && $numero <= 100) {
            echo "<ul>";
            // Comptador decreixent amb while
            while ($numero >= 1) {
                echo "<li>$numero</li>";
                $numero--;
            }
            echo "</ul>";
        } else {
            echo "<p style='color:red;'>Introdueix un número entre 1 i 100.</p>";
            echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
        }
    } else {
        echo "<p style='color:red;'>Has d’introduir un número vàlid.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>