<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat parell o senar</title>
</head>
<body>
    <h1>Resultat</h1>

    <?php
    // Comprovem si el número ha estat enviat i és vàlid
    if (isset($_GET['numero']) && is_numeric($_GET['numero'])) {
        $numero = (int) $_GET['numero'];

        if ($numero % 2 == 0) {
            echo "<p>El número <strong>$numero</strong> és <strong>parell</strong>.</p>";
        } else {
            echo "<p>El número <strong>$numero</strong> és <strong>senar</strong>.</p>";
        }
    } else {
        echo "<p style='color:red;'>Introdueix un número vàlid.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>