<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat d’edat legal</title>
</head>
<body>
    <h1>Resultat</h1>

    <?php
    // Comprovem si s'ha rebut el paràmetre 'edat'
    if (isset($_GET['edat']) && is_numeric($_GET['edat'])) {
        $edat = (int) $_GET['edat'];

        if ($edat >= 18) {
            echo "<p>Tens $edat anys: <strong>Ets major d’edat.</strong></p>";
        } else {
            echo "<p>Tens $edat anys: <strong>No ets major d’edat.</strong></p>";
        }
    } else {
        echo "<p style='color:red;'>Si us plau, introdueix una edat vàlida.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>
