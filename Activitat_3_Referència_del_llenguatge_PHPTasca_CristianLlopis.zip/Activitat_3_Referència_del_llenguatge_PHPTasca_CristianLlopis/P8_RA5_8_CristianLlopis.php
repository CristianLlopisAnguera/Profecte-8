<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Crea una funció que calculi el factorial d’un número enter positiu.
<?php
function factorial($n) {
    $resultat = 1;
    for ($i = 1; $i <= $n; $i++) {
        $resultat *= $i;
    }
    return $resultat;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num = intval($_POST["numero"]);
    echo "Factorial de $num és: " . factorial($num);
}
?>
<form method="post">
    Número: <input type="number" name="numero" min="0">
    <input type="submit" value="Calcular">
</form>
