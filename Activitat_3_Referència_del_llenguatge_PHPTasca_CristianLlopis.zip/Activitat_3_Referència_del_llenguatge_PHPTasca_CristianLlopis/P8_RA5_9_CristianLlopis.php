<?php
# Administració de sistemes informatics en Xarxa 
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025 

# Versió: 1.0

# Descripció(programa): Crea un array amb notes d’un alumne. Calcula la mitjana i mostra si està aprovat (5 o més).
<?php
$notes = [6.5, 4.3, 7.8, 5.0, 6.0];
$mitjana = array_sum($notes) / count($notes);
echo "Nota mitjana: $mitjana<br>";
echo $mitjana >= 5 ? "Està aprovat." : "No està aprovat.";
?>
