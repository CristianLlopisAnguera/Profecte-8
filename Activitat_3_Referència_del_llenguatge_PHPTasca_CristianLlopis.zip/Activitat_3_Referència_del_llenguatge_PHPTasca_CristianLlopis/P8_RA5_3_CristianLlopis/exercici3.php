<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 19/05/2025

# Versió: 1.0

# Descripció(programa): 
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat de la taula</title>
</head>
<body>
    <h1>Taula de multiplicar</h1>

    <?php
    // Comprovem si el número és vàlid i dins del rang
    if (isset($_GET['numero']) && is_numeric($_GET['numero'])) {
        $numero = (int) $_GET['numero'];

        if ($numero >= 1 && $numero <= 10) {
            echo "<h2>Taula del $numero</h2>";
            echo "<ul>";
            // Bucle per generar la taula del número
            for ($i = 1; $i <= 10; $i++) {
                $resultat = $numero * $i;
                echo "<li>$numero × $i = $resultat</li>";
            }
            echo "</ul>";
        } else {
            echo "<p style='color:red;'>El número ha d’estar entre 1 i 10.</p>";
            echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
        }
    } else {
        echo "<p style='color:red;'>Introdueix un número vàlid.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>