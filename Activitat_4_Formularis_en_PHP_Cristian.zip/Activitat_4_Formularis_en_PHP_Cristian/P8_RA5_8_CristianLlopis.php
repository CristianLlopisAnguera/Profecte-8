<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Si hi ha errors, torna a mostrar el formulari amb els valors prèviament introduïts.

$nom = $_POST["nom"] ?? "";
$email = $_POST["email"] ?? "";
$missatge = $_POST["missatge"] ?? "";
$error = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($nom) || empty($email) || empty($missatge)) {
        $error = true;
        echo "Tots els camps són obligatoris.<br><br>";
    } else {
        echo "Nom: $nom<br>Email: $email<br>Missatge: $missatge";
        exit;
    }
}
?>

<form method="post">
    Nom: <input type="text" name="nom" value="<?= htmlspecialchars($nom) ?>"><br>
    Email: <input type="text" name="email" value="<?= htmlspecialchars($email) ?>"><br>
    Missatge: <textarea name="missatge"><?= htmlspecialchars($missatge) ?></textarea><br>
    <input type="submit" value="Enviar">
</form>