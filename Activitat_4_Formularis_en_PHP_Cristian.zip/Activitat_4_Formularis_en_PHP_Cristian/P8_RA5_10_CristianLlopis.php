<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Formulari complet amb validació i missatges d'error en vermell.

$errors = [];
$nom = $_POST["nom"] ?? "";
$email = $_POST["email"] ?? "";
$assumpte = $_POST["assumpte"] ?? "";
$missatge = $_POST["missatge"] ?? "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($nom)) $errors[] = "El nom és obligatori.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "El correu no és vàlid.";
    if (empty($assumpte)) $errors[] = "L'assumpte és obligatori.";
    if (empty($missatge)) $errors[] = "El missatge és obligatori.";

    if (empty($errors)) {
        echo "<p style='color: green;'>Formulari enviat correctament!</p>";
        echo "Nom: $nom<br>Email: $email<br>Assumpte: $assumpte<br>Missatge: $missatge";
        exit;
    }
}
?>

<form method="post">
    Nom: <input type="text" name="nom" value="<?= htmlspecialchars($nom) ?>"><br>
    Email: <input type="text" name="email" value="<?= htmlspecialchars($email) ?>"><br>
    Assumpte: <input type="text" name="assumpte" value="<?= htmlspecialchars($assumpte) ?>"><br>
    Missatge: <textarea name="missatge"><?= htmlspecialchars($missatge) ?></textarea><br>
    <input type="submit" value="Enviar">
</form>

<?php
if (!empty($errors)) {
    echo "<ul style='color: red;'>";
    foreach ($errors as $error) {
        echo "<li>$error</li>";
    }
    echo "</ul>";
}
?>