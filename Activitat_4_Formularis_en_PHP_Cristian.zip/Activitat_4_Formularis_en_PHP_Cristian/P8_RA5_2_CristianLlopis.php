<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Crea un formulari amb els camps "nom" i "edat", que utilitzi el mètode GET. Mostra els valors rebuts a la mateixa pàgina.
?>

<form method="get">
    Nom: <input type="text" name="nom"><br>
    Edat: <input type="number" name="edat"><br>
    <input type="submit" value="Enviar">
</form>

<?php
if (!empty($_GET)) {
    echo "Nom: " . htmlspecialchars($_GET["nom"]) . "<br>";
    echo "Edat: " . htmlspecialchars($_GET["edat"]);
}
?>