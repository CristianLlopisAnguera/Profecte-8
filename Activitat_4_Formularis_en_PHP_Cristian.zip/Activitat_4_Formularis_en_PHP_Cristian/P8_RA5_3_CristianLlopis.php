<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Crea un formulari amb els camps "nom", "correu electrònic" i "missatge". Comprova que cap camp estigui buit abans de mostrar els valors.
?>

<form method="post">
    Nom: <input type="text" name="nom"><br>
    Correu electrònic: <input type="email" name="email"><br>
    Missatge: <textarea name="missatge"></textarea><br>
    <input type="submit" value="Enviar">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["nom"]) && !empty($_POST["email"]) && !empty($_POST["missatge"])) {
        echo "Nom: " . htmlspecialchars($_POST["nom"]) . "<br>";
        echo "Correu: " . htmlspecialchars($_POST["email"]) . "<br>";
        echo "Missatge: " . htmlspecialchars($_POST["missatge"]);
    } else {
        echo "Tots els camps són obligatoris.";
    }
}
?>