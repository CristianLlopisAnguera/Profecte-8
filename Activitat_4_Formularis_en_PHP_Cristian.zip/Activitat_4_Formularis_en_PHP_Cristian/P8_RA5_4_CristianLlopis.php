<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Crea un formulari amb un camp d’email i valida que sigui un format de correu vàlid.
?>

<form method="post">
    Email: <input type="text" name="email">
    <input type="submit" value="Validar">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Correu vàlid: " . htmlspecialchars($email);
    } else {
        echo "Format de correu invàlid.";
    }
}
?>