<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Mostra un comentari utilitzant htmlspecialchars per evitar injeccions HTML.
?>

<form method="post">
    Comentari: <textarea name="comentari"></textarea><br>
    <input type="submit" value="Enviar">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $comentari = htmlspecialchars($_POST["comentari"]);
    echo "Comentari rebut: $comentari";
}
?>