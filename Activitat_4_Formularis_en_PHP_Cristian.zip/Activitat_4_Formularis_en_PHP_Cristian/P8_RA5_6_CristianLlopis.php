<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Crea un formulari amb un camp select per triar ciutat i mostra la ciutat seleccionada.
?>

<form method="post">
    Ciutat:
    <select name="ciutat">
        <option value="Barcelona">Barcelona</option>
        <option value="València">València</option>
        <option value="Tarragona">Tarragona</option>
    </select>
    <input type="submit" value="Enviar">
</form>

<?php
if (isset($_POST["ciutat"])) {
    echo "Ciutat seleccionada: " . htmlspecialchars($_POST["ciutat"]);
}
?>