<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Crea un formulari amb radio buttons per seleccionar el gènere. Mostra el gènere triat.
?>

<form method="post">
    Gènere:<br>
    <input type="radio" name="genere" value="Home"> Home<br>
    <input type="radio" name="genere" value="Dona"> Dona<br>
    <input type="radio" name="genere" value="Altres"> Altres<br>
    <input type="submit" value="Enviar">
</form>

<?php
if (isset($_POST["genere"])) {
    echo "Has seleccionat: " . htmlspecialchars($_POST["genere"]);
}
?>