<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Fes un formulari amb una llista de checkbox (ex: aficions). Mostra els valors seleccionats.
?>

<form method="post">
    Aficions:<br>
    <input type="checkbox" name="aficions[]" value="Llegir"> Llegir<br>
    <input type="checkbox" name="aficions[]" value="Esport"> Esport<br>
    <input type="checkbox" name="aficions[]" value="Música"> Música<br>
    <input type="submit" value="Enviar">
</form>

<?php
if (!empty($_POST["aficions"])) {
    echo "Has seleccionat:<ul>";
    foreach ($_POST["aficions"] as $aficio) {
        echo "<li>" . htmlspecialchars($aficio) . "</li>";
    }
    echo "</ul>";
}
?>