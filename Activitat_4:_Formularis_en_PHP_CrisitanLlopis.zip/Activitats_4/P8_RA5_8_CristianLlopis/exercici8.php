<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Validació i reompliment</title>
</head>
<body>
    <h1>Resultat del formulari</h1>

    <?php
    // Inicialitzem les variables amb valors rebuts (si n'hi ha)
    $nom = isset($_GET['nom']) ? htmlspecialchars($_GET['nom']) : '';
    $correu = isset($_GET['correu']) ? htmlspecialchars($_GET['correu']) : '';
    $missatge = isset($_GET['missatge']) ? htmlspecialchars($_GET['missatge']) : '';

    // Comprovem si algun camp és buit
    if (empty(trim($nom)) || empty(trim($correu)) || empty(trim($missatge))) {
        echo "<p style='color:red;'>Tots els camps són obligatoris.</p>";

        // Tornem a mostrar el formulari amb els valors ja introduïts
        echo '
        <form action="exercici8.php" method="get">
            <label for="nom">Nom:</label>
            <input type="text" id="nom" name="nom" value="' . $nom . '"><br><br>

            <label for="correu">Correu electrònic:</label>
            <input type="email" id="correu" name="correu" value="' . $correu . '"><br><br>

            <label for="missatge">Missatge:</label><br>
            <textarea id="missatge" name="missatge" rows="5" cols="30">' . $missatge . '</textarea><br><br>

            <input type="submit" value="Envia">
        </form>';
    } else {
        // Si tot és correcte, mostrem els valors
        echo "<p><strong>Nom:</strong> $nom</p>";
        echo "<p><strong>Correu electrònic:</strong> $correu</p>";
        echo "<p><strong>Missatge:</strong><br>$missatge</p>";
    }
    ?>
</body>
</html>