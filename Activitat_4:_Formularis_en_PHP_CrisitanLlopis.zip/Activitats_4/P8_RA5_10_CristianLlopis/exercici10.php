<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat del contacte</title>
    <style>
        .error { color: red; }
        .correcte { color: green; }
    </style>
</head>
<body>
    <h1>Resultat del formulari</h1>

    <?php
    // Inicialitzem les variables i recollim els valors amb seguretat
    $nom = isset($_GET['nom']) ? trim($_GET['nom']) : '';
    $email = isset($_GET['email']) ? trim($_GET['email']) : '';
    $assumpte = isset($_GET['assumpte']) ? trim($_GET['assumpte']) : '';
    $missatge = isset($_GET['missatge']) ? trim($_GET['missatge']) : '';

    $errors = [];

    // Validacions
    if (empty($nom)) $errors[] = "El camp <strong>nom</strong> és obligatori.";
    if (empty($email)) {
        $errors[] = "El camp <strong>email</strong> és obligatori.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "El correu electrònic no té un format vàlid.";
    }
    if (empty($assumpte)) $errors[] = "El camp <strong>assumpte</strong> és obligatori.";
    if (empty($missatge)) $errors[] = "El camp <strong>missatge</strong> és obligatori.";

    // Mostrar errors o confirmació
    if (!empty($errors)) {
        echo "<div class='error'><ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul></div>";

        // Tornem a mostrar el formulari amb els valors anteriors
        echo '
        <form action="exercici10.php" method="get">
            <label for="nom">Nom:</label><br>
            <input type="text" id="nom" name="nom" value="' . htmlspecialchars($nom) . '"><br><br>

            <label for="email">Correu electrònic:</label><br>
            <input type="email" id="email" name="email" value="' . htmlspecialchars($email) . '"><br><br>

            <label for="assumpte">Assumpte:</label><br>
            <input type="text" id="assumpte" name="assumpte" value="' . htmlspecialchars($assumpte) . '"><br><br>

            <label for="missatge">Missatge:</label><br>
            <textarea id="missatge" name="missatge" rows="5" cols="40">' . htmlspecialchars($missatge) . '</textarea><br><br>

            <input type="submit" value="Envia">
        </form>';
    } else {
        echo "<p class='correcte'>El teu missatge s'ha enviat correctament!</p>";
        echo "<p><strong>Nom:</strong> " . htmlspecialchars($nom) . "</p>";
        echo "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
        echo "<p><strong>Assumpte:</strong> " . htmlspecialchars($assumpte) . "</p>";
        echo "<p><strong>Missatge:</strong><br>" . nl2br(htmlspecialchars($missatge)) . "</p>";
    }
    ?>
</body>
</html>