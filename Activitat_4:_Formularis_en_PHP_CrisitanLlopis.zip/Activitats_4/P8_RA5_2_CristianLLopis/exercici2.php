<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat del formulari</title>
</head>
<body>
    <h1>Dades rebudes</h1>

    <?php
    // Comprovem si els valors han estat enviats per GET
    if (isset($_GET['nom']) && isset($_GET['edat'])) {
        // Assignem els valors a variables
        $nom = htmlspecialchars($_GET['nom']);
        $edat = htmlspecialchars($_GET['edat']);

        // Mostrem els valors per pantalla
        echo "<p>Nom: $nom</p>";
        echo "<p>Edat: $edat</p>";
    } else {
        // Si no s'han rebut dades, mostrem un missatge
        echo "<p>No s'han rebut dades. Torna al formulari i omple els camps.</p>";
    }
    ?>
</body>
</html>