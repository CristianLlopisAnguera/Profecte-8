<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Comentari rebut</title>
</head>
<body>
    <h1>Comentari rebut</h1>

    <?php
    // Comprovem si s'ha rebut el camp 'comentari'
    if (isset($_GET['comentari']) && !empty(trim($_GET['comentari']))) {
        // Sanititzem la dada amb htmlspecialchars per evitar injecció HTML
        $comentari = htmlspecialchars($_GET['comentari']);
        echo "<p><strong>Comentari:</strong></p>";
        echo "<div style='border:1px solid #ccc; padding:10px;'>$comentari</div>";
    } else {
        echo "<p style='color:red;'>No has escrit cap comentari.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>