<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat del formulari</title>
</head>
<body>
    <h1>Resultat del formulari</h1>

    <?php
    // Comprovem que tots els camps han estat enviats i no són buits
    if (
        isset($_GET['nom'], $_GET['email'], $_GET['missatge']) &&
        !empty(trim($_GET['nom'])) &&
        !empty(trim($_GET['email'])) &&
        !empty(trim($_GET['missatge']))
    ) {
        // Sanititzem les dades per seguretat
        $nom = htmlspecialchars($_GET['nom']);
        $email = htmlspecialchars($_GET['email']);
        $missatge = htmlspecialchars($_GET['missatge']);

        // Mostrem les dades
        echo "<p><strong>Nom:</strong> $nom</p>";
        echo "<p><strong>Correu electrònic:</strong> $email</p>";
        echo "<p><strong>Missatge:</strong><br>$missatge</p>";
    } else {
        // Missatge d'error si algun camp és buit
        echo "<p style='color: red;'>Error: Cal omplir tots els camps del formulari.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>