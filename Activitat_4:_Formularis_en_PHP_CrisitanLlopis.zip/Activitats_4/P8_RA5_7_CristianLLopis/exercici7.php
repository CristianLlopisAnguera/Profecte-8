<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat del gènere seleccionat</title>
</head>
<body>
    <h1>Gènere seleccionat</h1>

    <?php
    // Comprovem si s'ha seleccionat el gènere
    if (isset($_GET['genere']) && !empty($_GET['genere'])) {
        $genere = htmlspecialchars($_GET['genere']);
        echo "<p>Has seleccionat: <strong>$genere</strong></p>";
    } else {
        echo "<p style='color:red;'>No has seleccionat cap gènere.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>