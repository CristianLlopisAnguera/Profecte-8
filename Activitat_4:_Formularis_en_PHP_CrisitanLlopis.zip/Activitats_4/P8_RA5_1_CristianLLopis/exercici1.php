<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 21/05/2025

# Versió: 1.0

# Descripció(programa): Crea un formulari amb un sol camp de text per introduir un nom.
# Mostra un missatge de benvinguda amb el nom introduït després de fer clic a "Enviar".
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resposta</title>
</head>
<body>
    
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["nom"])) {
    $nom = htmlspecialchars($_POST["nom"]);
    echo "Benvingut/da, $nom!";
} else {
    echo "No has introduït cap nom.";
}
?>
</body>
</html>
