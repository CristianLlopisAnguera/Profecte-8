<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat de la validació</title>
</head>
<body>
    <h1>Resultat</h1>

    <?php
    // Comprovem si s'ha enviat el camp 'email'
    if (isset($_GET['email'])) {
        $email = trim($_GET['email']);

        // Validem que el correu sigui vàlid
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<p>El correu electrònic <strong>" . htmlspecialchars($email) . "</strong> és vàlid </p>";
        } else {
            echo "<p style='color: red;'> El correu introduït no és vàlid.</p>";
            echo "<p><a href='formulari.html'>Torna a provar-ho</a></p>";
        }
    } else {
        echo "<p style='color: red;'>No s'ha rebut cap correu electrònic.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>
