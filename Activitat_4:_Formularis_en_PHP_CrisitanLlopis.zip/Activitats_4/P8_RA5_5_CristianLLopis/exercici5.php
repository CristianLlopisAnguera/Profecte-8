<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Aficions seleccionades</title>
</head>
<body>
    <h1>Les teves aficions</h1>

    <?php
    // Comprovem si s'ha enviat el formulari i s'ha seleccionat almenys una afició
    if (isset($_GET['aficions']) && is_array($_GET['aficions']) && count($_GET['aficions']) > 0) {
        echo "<p>Has seleccionat les següents aficions:</p>";
        echo "<ul>";

        // Recorrem les aficions seleccionades
        foreach ($_GET['aficions'] as $aficio) {
            echo "<li>" . htmlspecialchars($aficio) . "</li>";
        }

        echo "</ul>";
    } else {
        echo "<p style='color:red;'>No has seleccionat cap afició.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>
