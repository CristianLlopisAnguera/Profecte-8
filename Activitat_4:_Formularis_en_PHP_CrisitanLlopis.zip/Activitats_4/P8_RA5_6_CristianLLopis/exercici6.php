<?php 
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 22/05/2025

# Versió: 1.0

# Descripció(programa):
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Resultat de la selecció</title>
</head>
<body>
    <h1>Ciutat seleccionada</h1>

    <?php
    // Comprovem si s'ha rebut el valor 'ciutat' i no és buit
    if (isset($_GET['ciutat']) && !empty(trim($_GET['ciutat']))) {
        $ciutat = htmlspecialchars($_GET['ciutat']);
        echo "<p>Has seleccionat la ciutat: <strong>$ciutat</strong></p>";
    } else {
        echo "<p style='color:red;'>No has seleccionat cap ciutat.</p>";
        echo "<p><a href='formulari.html'>Torna al formulari</a></p>";
    }
    ?>
</body>
</html>