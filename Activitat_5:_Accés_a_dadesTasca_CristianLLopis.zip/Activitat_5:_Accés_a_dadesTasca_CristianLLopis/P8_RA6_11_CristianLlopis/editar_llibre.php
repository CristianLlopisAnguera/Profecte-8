<?php
// Mostrar errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexió MySQL
$host = 'db';
$usuari = 'usuari';
$contrasenya = 'contrasenya';
$bd = 'biblioteca';
$conn = mysqli_connect($host, $usuari, $contrasenya, $bd);

if (!$conn) {
    die("<p style='color:red;'>Error de connexió: " . mysqli_connect_error() . "</p>");
}

$missatge = "";
$actualitzat = false;

// Validació i actualització
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $titol = trim($_POST['titol']);
    $autor = trim($_POST['autor']);
    $any = trim($_POST['any']);

    // Validació: cap camp buit
    if ($titol === "" || $autor === "" || $any === "") {
        $missatge = "<p style='color:red;'>Tots els camps són obligatoris.</p>";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE llibres SET titol=?, autor=?, any=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssii", $titol, $autor, intval($any), $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $missatge = "<p style='color:green; font-weight: bold;'>Llibre actualitzat correctament!</p>";
        $actualitzat = true;
    }
}

// Si hi ha ID per editar, mostra el formulari
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = mysqli_query($conn, "SELECT * FROM llibres WHERE id=$id");
    $llibre = mysqli_fetch_assoc($result);

    if ($llibre) {
        echo "<h2>Edita llibre</h2>";
        echo $missatge;
        ?>
        <form method="post" action="editar_llibre.php?id=<?= $id ?>">
            <input type="hidden" name="id" value="<?= $llibre['id'] ?>">
            <label>Títol: <input type="text" name="titol" value="<?= htmlspecialchars($llibre['titol']) ?>" required></label><br>
            <label>Autor: <input type="text" name="autor" value="<?= htmlspecialchars($llibre['autor']) ?>" required></label><br>
            <label>Any: <input type="number" name="any" value="<?= htmlspecialchars($llibre['any']) ?>" required></label><br>
            <input type="submit" value="Desar canvis">
        </form>
        <hr>
        <?php
    } else {
        echo "<p style='color:red;'>Llibre no trobat.</p>";
    }
}

// Mostrar taula amb enllaços "Editar"
$resultat = mysqli_query($conn, "SELECT * FROM llibres");

echo "<h2>Llibres</h2>";
echo $actualitzat ? "<p style='background: #d4edda; padding: 10px; border-left: 5px solid green;'>Els canvis s'han desat correctament.</p>" : "";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Títol</th><th>Autor</th><th>Any</th><th>Acció</th></tr>";

while ($fila = mysqli_fetch_assoc($resultat)) {
    echo "<tr>";
    echo "<td>{$fila['id']}</td>";
    echo "<td>" . htmlspecialchars($fila['titol']) . "</td>";
    echo "<td>" . htmlspecialchars($fila['autor']) . "</td>";
    echo "<td>{$fila['any']}</td>";
    echo "<td><a href='editar_llibre.php?id={$fila['id']}'>Editar</a></td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>