<?php
// Mostra errors per a depuració
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Dades de connexió
$host = 'db';
$usuari = 'usuari';
$contrasenya = 'contrasenya';
$bd = 'biblioteca';

// Connexió a la base de dades
$connexio = mysqli_connect($host, $usuari, $contrasenya, $bd);

// Comprovació de connexió
if (!$connexio) {
    die("<p style='color:red;'>Error de connexió: " . mysqli_connect_error() . "</p>");
}

// Consulta de llibres
$sql = "SELECT id, titol, autor, any FROM llibres";
$resultat = mysqli_query($connexio, $sql);

// Mostrar resultats en una taula
echo "<h1>Llibres</h1>";
if (mysqli_num_rows($resultat) > 0) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Títol</th><th>Autor</th><th>Any</th></tr>";
    while ($fila = mysqli_fetch_assoc($resultat)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($fila['id']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['titol']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['autor']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['any']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No s'han trobat llibres.</p>";
}

mysqli_close($connexio);
?>
