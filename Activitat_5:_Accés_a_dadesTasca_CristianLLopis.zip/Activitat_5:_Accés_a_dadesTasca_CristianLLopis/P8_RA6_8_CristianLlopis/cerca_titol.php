<?php
// Mostrar errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexió
$host = 'db';
$usuari = 'usuari';
$contrasenya = 'contrasenya';
$bd = 'biblioteca';

$connexio = mysqli_connect($host, $usuari, $contrasenya, $bd);
if (!$connexio) {
    die("<p style='color:red;'>Error de connexió: " . mysqli_connect_error() . "</p>");
}

// Validació de l’entrada
if (isset($_GET['titol']) && !empty(trim($_GET['titol']))) {
    $paraula = '%' . trim($_GET['titol']) . '%';

    // Consulta amb LIKE i prepared statement
    $stmt = mysqli_prepare($connexio, "SELECT id, titol, autor, any FROM llibres WHERE titol LIKE ?");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $paraula);
        mysqli_stmt_execute($stmt);
        $resultat = mysqli_stmt_get_result($stmt);

        echo "<h1>Resultats de la cerca per títol</h1>";

        if (mysqli_num_rows($resultat) > 0) {
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>ID</th><th>Títol</th><th>Autor</th><th>Any</th></tr>";

            while ($fila = mysqli_fetch_assoc($resultat)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($fila['id']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['titol']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['autor']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['any']) . "</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "<p>No s'han trobat llibres amb aquesta paraula al títol.</p>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<p style='color:red;'>Error a la consulta: " . mysqli_error($connexio) . "</p>";
    }
} else {
    echo "<p style='color:red;'>Has d’introduir una paraula clau.</p>";
    echo "<a href='cerca_titol.html'>Tornar</a>";
}

mysqli_close($connexio);
?>