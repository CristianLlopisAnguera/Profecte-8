<?php
// Mostrar errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexió a la base de dades
$host = 'db';
$usuari = 'usuari';
$contrasenya = 'contrasenya';
$bd = 'biblioteca';

$connexio = mysqli_connect($host, $usuari, $contrasenya, $bd);
if (!$connexio) {
    die("<p style='color:red;'>Error de connexió: " . mysqli_connect_error() . "</p>");
}

// Consulta ordenada per any descendent
$sql = "SELECT id, titol, autor, any FROM llibres ORDER BY any DESC";
$resultat = mysqli_query($connexio, $sql);

echo "<h1>Llistat de llibres per any (descendent)</h1>";

if (mysqli_num_rows($resultat) > 0) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Títol</th><th>Autor</th><th>Any</th></tr>";

    while ($fila = mysqli_fetch_assoc($resultat)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($fila['id']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['titol']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['autor']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['any']) . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "<p>No hi ha llibres registrats.</p>";
}

mysqli_close($connexio);
?>