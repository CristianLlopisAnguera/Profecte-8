<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexió a la BD 'usuaris'
$conn = mysqli_connect('db', 'usuari', 'contrasenya', 'usuaris');
if (!$conn) die("Error de connexió: " . mysqli_connect_error());

$missatge = "";

// AFEGIR CLIENT
if ($_SERVER["REQUEST_METHOD"] === "POST" && $_POST['accio'] === 'afegir') {
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    if ($nom !== "" && $email !== "") {
        $stmt = mysqli_prepare($conn, "INSERT INTO clients (nom, email) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "ss", $nom, $email);
        mysqli_stmt_execute($stmt);
        $missatge = "<p style='color:green;'>Client afegit correctament.</p>";
        mysqli_stmt_close($stmt);
    } else {
        $missatge = "<p style='color:red;'>Tots els camps són obligatoris.</p>";
    }
}

// ELIMINAR CLIENT
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['eliminar']);
    $stmt = mysqli_prepare($conn, "DELETE FROM clients WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $missatge = "<p style='color:red;'>Client eliminat correctament.</p>";
    mysqli_stmt_close($stmt);
}

// EDITAR CLIENT
if ($_SERVER["REQUEST_METHOD"] === "POST" && $_POST['accio'] === 'editar') {
    $id = intval($_POST['id']);
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    if ($nom !== "" && $email !== "") {
        $stmt = mysqli_prepare($conn, "UPDATE clients SET nom=?, email=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssi", $nom, $email, $id);
        mysqli_stmt_execute($stmt);
        $missatge = "<p style='color:green;'>Client actualitzat correctament.</p>";
        mysqli_stmt_close($stmt);
    } else {
        $missatge = "<p style='color:red;'>Cap camp pot estar buit.</p>";
    }
}

// FORMULARI PER EDITAR
if (isset($_GET['editar'])) {
    $id = intval($_GET['editar']);
    $result = mysqli_query($conn, "SELECT * FROM clients WHERE id=$id");
    $client = mysqli_fetch_assoc($result);
    ?>
    <h3>Editar client</h3>
    <form method="post" action="clients.php">
        <input type="hidden" name="accio" value="editar">
        <input type="hidden" name="id" value="<?= $client['id'] ?>">
        <label>Nom: <input type="text" name="nom" value="<?= htmlspecialchars($client['nom']) ?>" required></label><br>
        <label>Email: <input type="email" name="email" value="<?= htmlspecialchars($client['email']) ?>" required></label><br>
        <input type="submit" value="Desar canvis">
    </form>
    <hr>
    <?php
}

// LLISTAT DE CLIENTS
echo $missatge;
$resultat = mysqli_query($conn, "SELECT * FROM clients");

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Nom</th><th>Email</th><th>Accions</th></tr>";

while ($fila = mysqli_fetch_assoc($resultat)) {
    $id = $fila['id'];
    $nom = htmlspecialchars($fila['nom']);
    $email = htmlspecialchars($fila['email']);
    echo "<tr>";
    echo "<td>$id</td><td>$nom</td><td>$email</td>";
    echo "<td>
        <a href='clients.php?editar=$id'>Editar</a> |
        <a href='clients.php?eliminar=$id' onclick=\"return confirm('Vols eliminar aquest client?');\">Eliminar</a>
    </td>";
    echo "</tr>";
}
echo "</table>";

mysqli_close($conn);
?>