<?php
// Mostrar errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexió a la base de dades
$host = 'db';
$usuari = 'usuari';
$contrasenya = 'contrasenya';
$bd = 'biblioteca';

$connexio = mysqli_connect($host, $usuari, $contrasenya, $bd);
if (!$connexio) {
    die("<p style='color:red;'>Error de connexió: " . mysqli_connect_error() . "</p>");
}

// Agafa dades del formulari
$titol = $_POST['titol'];
$autor = $_POST['autor'];
$any = $_POST['any'];

// Evita problemes amb SQL injectant seguretat
$titol = mysqli_real_escape_string($connexio, $titol);
$autor = mysqli_real_escape_string($connexio, $autor);
$any = intval($any); // Assegurem que és número

// Inserir llibre
$sql = "INSERT INTO llibres (titol, autor, any) VALUES ('$titol', '$autor', $any)";
if (mysqli_query($connexio, $sql)) {
    echo "<p style='color:green;'>Llibre afegit correctament!</p>";
    echo "<a href='afegir_llibre.html'>Afegir-ne un altre</a>";
} else {
    echo "<p style='color:red;'>Error en afegir el llibre: " . mysqli_error($connexio) . "</p>";
}

mysqli_close($connexio);
?>