<?php
// Mostrar errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexió
$host = 'db';
$usuari = 'usuari';
$contrasenya = 'contrasenya';
$bd = 'biblioteca';

$connexio = mysqli_connect($host, $usuari, $contrasenya, $bd);
if (!$connexio) {
    die("<p style='color:red;'>Error de connexió: " . mysqli_connect_error() . "</p>");
}

// Comprovar si s’han rebut tots els camps
if (
    isset($_POST['titol']) && !empty(trim($_POST['titol'])) &&
    isset($_POST['autor']) && !empty(trim($_POST['autor'])) &&
    isset($_POST['any']) && is_numeric($_POST['any'])
) {
    $titol = mysqli_real_escape_string($connexio, trim($_POST['titol']));
    $autor = mysqli_real_escape_string($connexio, trim($_POST['autor']));
    $any = intval($_POST['any']);

    // Inserció
    $sql = "INSERT INTO llibres (titol, autor, any) VALUES ('$titol', '$autor', $any)";
    if (mysqli_query($connexio, $sql)) {
        echo "<p style='color:green;'>Llibre afegit correctament!</p>";
        echo "<a href='afegir_llibre_bo.html'>Afegir-ne un altre</a>";
    } else {
        echo "<p style='color:red;'>Error en afegir el llibre: " . mysqli_error($connexio) . "</p>";
    }
} else {
    echo "<p style='color:red;'>Tots els camps són obligatoris i l'any ha de ser un número.</p>";
    echo "<a href='afegir_llibre_bo.html'>Tornar</a>";
}

mysqli_close($connexio);
?>