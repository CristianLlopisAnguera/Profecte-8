<?php
// Mostrar errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexió a la base de dades
$host = 'db';
$usuari = 'usuari';
$contrasenya = 'contrasenya';
$bd = 'biblioteca';

$connexio = mysqli_connect($host, $usuari, $contrasenya, $bd);
if (!$connexio) {
    die("<p style='color:red;'>Error de connexió: " . mysqli_connect_error() . "</p>");
}

// Validació bàsica del formulari
if (
    isset($_POST['titol']) && !empty(trim($_POST['titol'])) &&
    isset($_POST['autor']) && !empty(trim($_POST['autor'])) &&
    isset($_POST['any']) && is_numeric($_POST['any'])
) {
    $titol = trim($_POST['titol']);
    $autor = trim($_POST['autor']);
    $any = intval($_POST['any']);

    // Crear la sentència preparada
    $stmt = mysqli_prepare($connexio, "INSERT INTO llibres (titol, autor, any) VALUES (?, ?, ?)");

    if ($stmt) {
        // Enllaçar paràmetres (s = string, i = integer)
        mysqli_stmt_bind_param($stmt, "ssi", $titol, $autor, $any);

        // Executar la consulta
        if (mysqli_stmt_execute($stmt)) {
            echo "<p style='color:green;'>Llibre afegit correctament!</p>";
            echo "<a href='afegir_llibre_5.html'>Afegir-ne un altre</a>";
        } else {
            echo "<p style='color:red;'>Error en afegir el llibre: " . mysqli_stmt_error($stmt) . "</p>";
        }

        // Tancar la sentència
        mysqli_stmt_close($stmt);
    } else {
        echo "<p style='color:red;'>Error al preparar la consulta: " . mysqli_error($connexio) . "</p>";
    }
} else {
    echo "<p style='color:red;'>Tots els camps són obligatoris i l'any ha de ser un número.</p>";
    echo "<a href='afegir_llibre_5.html'>Tornar</a>";
}

mysqli_close($connexio);
?>
