<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = mysqli_connect('db', 'usuari', 'contrasenya', 'biblioteca');
if (!$conn) die("Error de connexió: " . mysqli_connect_error());

$accio = $_REQUEST['accio'] ?? 'llistar';

function escapar($text) {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

// AFEGIR
if ($accio === 'afegir' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $titol = trim($_POST['titol']);
    $autor = trim($_POST['autor']);
    $any = intval($_POST['any']);
    if ($titol && $autor && $any) {
        $stmt = mysqli_prepare($conn, "INSERT INTO llibres (titol, autor, any) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssi", $titol, $autor, $any);
        mysqli_stmt_execute($stmt);
        echo "<p style='color:green;'>Llibre afegit correctament!</p>";
        mysqli_stmt_close($stmt);
    } else {
        echo "<p style='color:red;'>Tots els camps són obligatoris.</p>";
    }
}

// EDITAR
if ($accio === 'editar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $titol = trim($_POST['titol']);
    $autor = trim($_POST['autor']);
    $any = intval($_POST['any']);
    if ($titol && $autor && $any) {
        $stmt = mysqli_prepare($conn, "UPDATE llibres SET titol=?, autor=?, any=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssii", $titol, $autor, $any, $id);
        mysqli_stmt_execute($stmt);
        echo "<p style='color:green;'>Llibre actualitzat correctament!</p>";
        mysqli_stmt_close($stmt);
    } else {
        echo "<p style='color:red;'>Tots els camps són obligatoris.</p>";
    }
}

// ELIMINAR
if ($accio === 'eliminar') {
    $id = intval($_GET['id']);
    $stmt = mysqli_prepare($conn, "DELETE FROM llibres WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    echo "<p style='color:red;'>Llibre eliminat correctament.</p>";
    mysqli_stmt_close($stmt);
}

// FORMULARI EDITAR
if ($accio === 'form_editar') {
    $id = intval($_GET['id']);
    $res = mysqli_query($conn, "SELECT * FROM llibres WHERE id=$id");
    $llibre = mysqli_fetch_assoc($res);
    ?>
    <h2>Editar llibre</h2>
    <form action="llibres.php" method="post">
        <input type="hidden" name="accio" value="editar">
        <input type="hidden" name="id" value="<?= $llibre['id'] ?>">
        <label>Títol: <input type="text" name="titol" value="<?= escapar($llibre['titol']) ?>" required></label><br>
        <label>Autor: <input type="text" name="autor" value="<?= escapar($llibre['autor']) ?>" required></label><br>
        <label>Any: <input type="number" name="any" value="<?= $llibre['any'] ?>" required></label><br>
        <input type="submit" value="Desar canvis">
    </form>
    <?php
    exit;
}

// CERCAR
if ($accio === 'cercar') {
    $titol = '%' . $_GET['titol'] . '%';
    $stmt = mysqli_prepare($conn, "SELECT * FROM llibres WHERE titol LIKE ?");
    mysqli_stmt_bind_param($stmt, "s", $titol);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $result = mysqli_query($conn, "SELECT * FROM llibres");
}

// LLISTAR RESULTATS
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Títol</th><th>Autor</th><th>Any</th><th>Accions</th></tr>";

while ($fila = mysqli_fetch_assoc($result)) {
    $id = $fila['id'];
    echo "<tr>";
    echo "<td>{$id}</td><td>" . escapar($fila['titol']) . "</td><td>" . escapar($fila['autor']) . "</td><td>{$fila['any']}</td>";
    echo "<td>
        <a href='llibres.php?accio=form_editar&id=$id' target='_parent'>Editar</a> |
        <a href='llibres.php?accio=eliminar&id=$id' onclick=\"return confirm('Vols eliminar aquest llibre?');\">Eliminar</a>
    </td>";
    echo "</tr>";
}
echo "</table>";
mysqli_close($conn);
?>