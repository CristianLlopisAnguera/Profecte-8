<?php
// Mostrar errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexió MySQL
$host = 'db';
$usuari = 'usuari';
$contrasenya = 'contrasenya';
$bd = 'biblioteca';
$conn = mysqli_connect($host, $usuari, $contrasenya, $bd);

if (!$conn) {
    die("<p style='color:red;'>Error de connexió: " . mysqli_connect_error() . "</p>");
}

$missatge = "";
$actualitzat = false;

// Eliminar llibre
if (isset($_GET['eliminar'])) {
    $idEliminar = intval($_GET['eliminar']);
    $stmt = mysqli_prepare($conn, "DELETE FROM llibres WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $idEliminar);
    if (mysqli_stmt_execute($stmt)) {
        $missatge = "<p style='color:red; font-weight:bold;'>Llibre amb ID $idEliminar eliminat correctament.</p>";
    } else {
        $missatge = "<p style='color:red;'>Error en eliminar el llibre.</p>";
    }
    mysqli_stmt_close($stmt);
}

// Actualitzar llibre
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $titol = trim($_POST['titol']);
    $autor = trim($_POST['autor']);
    $any = trim($_POST['any']);

    if ($titol === "" || $autor === "" || $any === "") {
        $missatge = "<p style='color:red;'>Tots els camps són obligatoris.</p>";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE llibres SET titol=?, autor=?, any=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssii", $titol, $autor, intval($any), $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $missatge = "<p style='color:green; font-weight: bold;'>Llibre actualitzat correctament!</p>";
        $actualitzat = true;
    }
}

// Formulari d'edició
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = mysqli_query($conn, "SELECT * FROM llibres WHERE id=$id");
    $llibre = mysqli_fetch_assoc($result);

    if ($llibre) {
        echo "<h2>Edita llibre</h2>";
        echo $missatge;
        ?>
        <form method="post" action="editar_llibre.php?id=<?= $id ?>">
            <input type="hidden" name="id" value="<?= $llibre['id'] ?>">
            <label>Títol: <input type="text" name="titol" value="<?= htmlspecialchars($llibre['titol']) ?>" required></label><br>
            <label>Autor: <input type="text" name="autor" value="<?= htmlspecialchars($llibre['autor']) ?>" required></label><br>
            <label>Any: <input type="number" name="any" value="<?= htmlspecialchars($llibre['any']) ?>" required></label><br>
            <input type="submit" value="Desar canvis">
        </form>
        <hr>
        <?php
    } else {
        echo "<p style='color:red;'>Llibre no trobat.</p>";
    }
}

// Mostrar taula de llibres
$resultat = mysqli_query($conn, "SELECT * FROM llibres");

echo "<h2>Llibres</h2>";
echo $missatge;
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Títol</th><th>Autor</th><th>Any</th><th>Accions</th></tr>";

while ($fila = mysqli_fetch_assoc($resultat)) {
    $id = $fila['id'];
    $titol = htmlspecialchars($fila['titol']);
    $autor = htmlspecialchars($fila['autor']);
    $any = $fila['any'];

    echo "<tr>";
    echo "<td>$id</td>";
    echo "<td>$titol</td>";
    echo "<td>$autor</td>";
    echo "<td>$any</td>";
    echo "<td>
        <a href='editar_llibre.php?id=$id'>Editar</a> |
        <a href='editar_llibre.php?eliminar=$id' onclick=\"return confirm('Segur que vols eliminar aquest llibre?');\">Eliminar</a>
    </td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>