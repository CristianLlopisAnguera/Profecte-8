<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Mostra els números del 10 a l’1 utilitzant un bucle while.

$i = 10;
while ($i >= 1) {
    echo "$i\n";
    $i--;
}
