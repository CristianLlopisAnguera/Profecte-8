<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Crea un array multidimensional amb dades de 3 usuaris i mostra si són majors d’edat en una taula HTML.

$usuaris = [
    ["nom" => "Anna", "correu" => "anna@example.com", "edat" => 17],
    ["nom" => "Joan", "correu" => "joan@example.com", "edat" => 19],
    ["nom" => "Marc", "correu" => "marc@example.com", "edat" => 18]
];

function esMajor($edat) {
    return $edat >= 18 ? "Sí" : "No";
}

echo "<table border='1'>";
echo "<tr><th>Nom</th><th>Correu</th><th>Edat</th><th>Major d’edat</th></tr>";
foreach ($usuaris as $usuari) {
    echo "<tr>";
    echo "<td>{$usuari['nom']}</td>";
    echo "<td>{$usuari['correu']}</td>";
    echo "<td>{$usuari['edat']}</td>";
    echo "<td>" . esMajor($usuari['edat']) . "</td>";
    echo "</tr>";
}
echo "</table>";