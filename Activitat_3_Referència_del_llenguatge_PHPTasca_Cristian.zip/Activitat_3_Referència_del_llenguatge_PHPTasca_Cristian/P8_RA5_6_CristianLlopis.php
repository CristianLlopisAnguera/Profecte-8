<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Declara un array associatiu amb noms i edats. Mostra només els alumnes de 18 anys o més.

$alumnes = [
    "Anna" => 17,
    "Joan" => 19,
    "Marc" => 18,
    "Laura" => 16,
    "Pau" => 20
];

foreach ($alumnes as $nom => $edat) {
    if ($edat >= 18) {
        echo "$nom és major d’edat ($edat anys)\n";
    }
}
