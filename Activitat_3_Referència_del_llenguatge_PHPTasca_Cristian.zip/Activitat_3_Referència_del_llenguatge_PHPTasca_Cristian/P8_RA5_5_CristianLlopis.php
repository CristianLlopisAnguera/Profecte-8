<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Crea un array amb 5 noms i mostra cada nom amb un bucle foreach.

$noms = ["Anna", "Joan", "Marc", "Laura", "Pau"];
foreach ($noms as $nom) {
    echo "$nom\n";
}