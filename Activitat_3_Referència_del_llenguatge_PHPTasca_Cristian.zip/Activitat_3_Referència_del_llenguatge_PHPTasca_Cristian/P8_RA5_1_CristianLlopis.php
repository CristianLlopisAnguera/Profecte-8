<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Demana l’edat d’una persona i mostra si és major d’edat o no.

echo "Introdueix la teva edat: ";
$edat = trim(fgets(STDIN));
if ($edat >= 18) {
    echo "Ets major d’edat.\n";
} else {
    echo "No ets major d’edat.\n";
}