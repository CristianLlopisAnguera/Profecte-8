<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Crea una funció que rebi un preu i un percentatge d’IVA i retorni el preu amb l’IVA aplicat.

function calcularIVA($preu, $iva) {
    return $preu + ($preu * $iva / 100);
}

echo "Preu amb IVA (100€ i 21%): " . calcularIVA(100, 21) . "€\n";