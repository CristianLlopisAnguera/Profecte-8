<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Crea una funció que calculi el factorial d’un número enter positiu.

function factorial($n) {
    $resultat = 1;
    for ($i = 1; $i <= $n; $i++) {
        $resultat *= $i;
    }
    return $resultat;
}

echo "Factorial de 5: " . factorial(5) . "\n";