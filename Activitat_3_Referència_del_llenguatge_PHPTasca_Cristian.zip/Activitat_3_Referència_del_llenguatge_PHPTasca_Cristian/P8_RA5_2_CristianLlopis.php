<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Introdueix un número i mostra si és parell o senar.

echo "Introdueix un número: ";
$numero = trim(fgets(STDIN));
if ($numero % 2 == 0) {
    echo "És un número parell.\n";
} else {
    echo "És un número senar.\n";
}