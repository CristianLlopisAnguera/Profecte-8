<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Demana un número de l’1 al 10 i mostra la seva taula de multiplicar amb un bucle.

echo "Introdueix un número de l’1 al 10: ";
$num = trim(fgets(STDIN));
if ($num >= 1 && $num <= 10) {
    for ($i = 1; $i <= 10; $i++) {
        echo "$num x $i = " . ($num * $i) . "\n";
    }
} else {
    echo "Número fora de rang.\n";
}