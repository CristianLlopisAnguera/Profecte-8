<?php
# Administració de sistemes informatics en Xarxa
# Autor: Cristian Llopis Anguera
# Data: 20/05/2025

# Versió: 1.0

# Descripció(programa): Crea un array amb notes d’un alumne. Calcula la mitjana i mostra si està aprovat (5 o més).

$notes = [5, 7, 8, 4, 6];
$mitjana = array_sum($notes) / count($notes);
echo "Nota mitjana: $mitjana\n";
if ($mitjana >= 5) {
    echo "Estàs aprovat.\n";
} else {
    echo "Estàs suspès.\n";
}